import Live 
from Launchpad import Launchpad 

def create_instance(c_instance):
	' Creates and returns the Launchpad script '
	return Launchpad(c_instance)

